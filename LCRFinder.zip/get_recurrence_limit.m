% SEND:
% ---- L,       a vector of the length for which you want to estimate the probability
% ---  N_limit, maximal tolerated number for random Frequent Elements
% ---- n,       size of alpha-bet (i.e., 20 if AA 4 if DNA)
% ---- k,       length of the element (i.e 3 if triplets, 6 if 6mers...)

% GET:
% ---- R_limit,  the minimal number of recurrences above which random effects are not expected

function num_R_limit = get_recurrence_limit(L, N_limit, A, K)

N = length(L);
r = 1:20;
Nr = length(r);
for i = 1:N
    
    % go over the stat of different number of recurrences (r)
    for j = 1:Nr
        [prb_ft(j), num_ft(j)] = analytic_approximation(L(i), r(j), A, K);
    end
    
    % find the minimal 'r' such that significance, as defined by the limits, is met.
    num_loc = find (num_ft < N_limit);
    if isempty(num_loc)
        num_R_limit(i) = NaN;
        continue;
    end
    num_R_limit(i) = r(num_loc(1));
    
end

