% SEND:
% --- S:    single sequence (AA or DNA) as a char
% --- K:    the K-mer degree 

% DO:
% --- get all the existing K-mers (of degree K) in the sequence
% --- find the locations of each of the K-mers in the sequence

% GET:
% --- for each K-mer the number of its recurrences (repeats), locations, intervals in the sequence

function [Kmers, repeats, intervals, locations] = get_Kmers_stat(SEQ, K)

% get the Kmers that exist in SEQS
Kmers = get_Kmers_in_seq(SEQ, K);

%  go over the Kmers
N = length(Kmers);
locations = cell(1,N);
intervals = cell(1,N);
repeats   = zeros(1,N);
for i = 1:N
%parfor i = 1:N
    %i
    % locations
    locations{i} = strfind(SEQ, Kmers{i});
    % interval
    intervals{i} = diff(locations{i});
    % total number of repetitions
    repeats(i)   = length(locations{i});  
end

















