% This function estimates the minimal number of recurrences within some
% length to define a FE, based on Bernoulli Statistics

% SEND:
% --- L:  length over which to claculate things
% --- T:  the tolerated number of expected FEs at random in this L (this is equivalent to setting a threshold on the Probability = TH/A)  
% --- A:  size of the alphabet (i.e., 4 for NT, 20 for AA)
% --- K:  the length of K-mers (the basic elements)

% USE:
% to find the minimal number of hexamers recurrences within a window of 1000bp, 
% such that expected No. of FEs (at random) in this window is 0.001:
% [min_rep, LIMIT] = determine_search_parameters(1000, 0.001, 4, 6);

function [min_rep, LIMIT] = determine_search_parameters(L, T, A, K)

LENGTH = 10:10:L;
num_R_limit = get_recurrence_limit(LENGTH, T, A, K);
%plot(LENGTH, num_R_limit, 'x');

U = unique(num_R_limit);
U(isnan(U)) = []; % remove Nan
for i = 1:length(U)
    min_rep(i) = U(i);
    LIMIT(i)   = max(LENGTH(num_R_limit <= U(i)));
end