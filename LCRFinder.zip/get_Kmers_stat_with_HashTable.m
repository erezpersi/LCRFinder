% This function get the locations, intervals and repeats of all K-mers in the input sequence (S), using Hash-table
% SEND:
% --- S: the sequence to analyze (as char)
% --- K: the size of K-mers (e.g., 3 for AA, 6 for NT)

% GET:
% --- the K-mers, their locations, inetravls and repeats

function [Kmer, REP, INT, LOC] = get_Kmers_stat_with_HashTable(SEQ, K)

% get all K-mers
%Kmer = get_6_mers;
Kmer = get_Kmers_in_seq(SEQ, K);
% PERFECT HASH TABLE OBJECT
MAP = containers.Map(Kmer,1:length(Kmer));
% INIT
Nk   = length(Kmer);
LOC  = cell(1,Nk);
INT  = cell(1,Nk);
REP  = zeros(1,Nk);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%     PROCESS the DNA SEQ    %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GO OVER SEQ and gather locations of the elements (K-mers) 
L  = length(SEQ);           % length of SEQ
Ne = L-K+1;                 % No. of elements (all non-unique K-mers) in SEQ
for i = 1:Ne
    % --- the element
    tmp_element = SEQ(i:i+K-1);
    % --- skip if the K-mer doesn't exist (i.e., contains 'N')
    if contains(tmp_element, 'N')
        continue;
    end
    % --- find its index in the K-mer table (! Using Perfect Hashing !)
    tmp_id = MAP(tmp_element);
    
    % ACCUMULATE LOCATIONS of K-mers: 
    LOC{tmp_id}  = [LOC{tmp_id} i]; % Locations
    
end

% GET INTERVALS and No. of Repeats - for each K-mer 
for i = 1:Nk
    INT{i} = diff(LOC{i});    % intervals
    REP(i)   = length(LOC{i});  % total number of repetitions
end

