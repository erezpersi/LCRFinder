% SEND:
% --- CO:     results of analyze_CO, after applying 'filter_FEs.m'
% --- METHOD  (optional):
%             * []    - default is order by level of periodcity and then by recurrences
%             * 'REC' - order by total number of recurrences
%             * 'MFI' - order by periodicity (i.e., No. of repeatitions in periods)

% GET:
% --- CO:     updated structure containing the info of the LEAD FEs

% NOTE:
% * THIS VERSION includes an update, such that the FEs are first shorted by how periodic their are (in all periods, not just MFI)
%                                    and the by how  recurring they are

function CO = sort_FEs(CO, METHOD)

% get K-mers (motifs) info of the current sequence
tmp_fe  = CO.new_FEs;
tmp_loc = CO.new_LOC;
tmp_rep = CO.new_REP;
tmp_int = CO.new_INT;

% analyze the periodicity of each FE
% 1) get MFI and RP
M = length(tmp_fe);
for m = 1:M
    tmp_I = tmp_int{m};
    tmp_mfi(m)     = mode(tmp_I);
    tmp_rep_mfi(m) = length(find(tmp_I == tmp_mfi(m)));
    tmp_rp(m)      = tmp_rep_mfi(m)/length(tmp_int{m});
    clear tmp_I
end
% --- put 0 in non-period cases (i.e., at least 2 recurrences must exist)
id_nop = find(tmp_rep_mfi <=1);
tmp_mfi(id_nop) = 0;
tmp_rep_mfi(id_nop) = 0;
tmp_rp(id_nop) = 0;
% 2) get all PERIODS (the first is MFI)
M = length(tmp_fe);
for m = 1:M
    tmp_I = tmp_int{m};
    [tmp_P, tmp_N] = rank_intervals(tmp_I);
    tmp_per{m}     = tmp_P;
    tmp_rep_per{m} = tmp_N;
    clear tmp_I tmp_P tmp_N
end

% if METHOD is specified
if strcmp(METHOD, 'MFI')
    % --- most periodic
    [X, id_lead]  = sort(tmp_rep_mfi, 'descend');
elseif strcmp(METHOD, 'REC')
    % --- most recurring
    [X, id_lead] = sort(tmp_rep, 'descend');
% THE DEFAULT IS to order first be the most periodic, then by the most recurring:
else
%     % Order first by the most periodic
%     [X, id_lead]  = sort(tmp_rep_mfi, 'descend');
%     % Then, if non-periodic cases exist (i.e., no MFI, no rep_mfi)  - order them by the number of total repetitions
%     id_cut = find(tmp_rep_mfi(id_lead)==0);
%     if ~isempty(id_cut)
%         id_1   = id_lead(1:id_cut(1)-1);
%         id_2   = id_lead(id_cut);
%         [~, id_s] = sort(tmp_rep(id_2), 'descend');
%         id_2 = id_2(id_s);
%         id_lead = [id_1 id_2];
%     end
    for m = 1:M
        tmp_sum(m) = sum(tmp_rep_per{m});
    end
    tmp_order = [tmp_sum; tmp_rep]';      % most periodic in all intervals, then most recurring
    %tmp_order = [tmp_rep_mfi; tmp_rep]'; % most periodic in MFI, then most recurring (intermixed word may be missed)
    [X, id_lead]  = sortrows(tmp_order, 'descend');
end
% NOTE: this way (the default), if no periodic structures, the most repetitive motifs are considered first

% save FEs info, ordered by the most periodic/recurring
CO.lead_method   = METHOD;
CO.lead_fe       = tmp_fe(id_lead);
CO.lead_rep      = tmp_rep(id_lead);
CO.lead_loc      = tmp_loc(id_lead);
CO.lead_int      = tmp_int(id_lead);
CO.lead_rp       = tmp_rp(id_lead);
CO.lead_mfi      = tmp_mfi(id_lead);
CO.lead_rep_mfi  = tmp_rep_mfi(id_lead);
CO.lead_per      = tmp_per(id_lead);
CO.lead_rep_per  = tmp_rep_per(id_lead);
