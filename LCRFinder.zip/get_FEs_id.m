% SEND:
% --- LOC     : the array containing the locations of each Element (K-mer) on the analyzed sequence
%     Parameters from theortical consideration (Bernulli Stat):
% --- min_rep : the minimal number of repetition of the Element (K-mer) to define it as a Frequent Element (FE)
% --- LIMIT   : the minimal range within "min_rep" must occur

% GET:
% --- ID: Vector of the ID of K-mers that qualify as FEs

function ID = get_FEs_id(LOC, min_rep, LIMIT)

% Number of parameter sets for search
Npar = length(min_rep);

% GO OVER FEs and check if recurs within LIMIT (i.e. local & non-random)
count = 0;
for f = 1:length(LOC)
    
    % locations
    fe_loc = LOC{f};
    Nr = length(fe_loc);
    
    % check if random
    
    for i = 1:Npar 
        dis = [];
        % go over every 'min_rep' repeats and check if appeared in local section (i.e., within LIMIT)
        for k = 1:Nr-min_rep(i)+1
            dis(k) = -(fe_loc(k) - fe_loc(k+min_rep(i)-1));
        end
        % if there's at least one local (i.e., non-random) pattern => keep this as FE
        if min(dis) <= LIMIT(i)
            count = count + 1;
            fe_keep(count) = f;
        else
            continue;
        end
        
    end
    
    clear fe_loc
    
end
% get the ID of FEs after correcting random effect
if count > 0
    ID = unique(fe_keep);
else
    ID = [];
end
