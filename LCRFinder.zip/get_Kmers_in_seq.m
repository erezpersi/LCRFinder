% SEND:
% --- SEQ, a sequence as a single char vector
% --- K, the Kmer degree of interest

% GET:
% --- Kmer, a cell array that contains all the Kmer of level K that exist in SEQ.

function Kmers = get_Kmers_in_seq(SEQ, K)

% Alphabet Size
A = length(unique(SEQ));
% Maximal number of different K-mers
% MAX = A^K;

% GO OVER SEQ and get existing K-mers on it
N = length(SEQ);
Kmers = cell(1,N-K+1);
for i = 1:N-K+1
    %i
    Kmers{i} = SEQ(i:i+K-1);
%     % STOP if MAX is attained. check every 100K letters (it consumes more time than it saves)
%     if mod(i,100000) == 0
%         tmp_Kmers = unique(Kmers(1:i));
%         if length(tmp_Kmers) >= MAX
%             Kmers = tmp_Kmers;
%             return;
%         end
%     end
end

% sorted by alpha-beit
Kmers = unique(Kmers);
    
