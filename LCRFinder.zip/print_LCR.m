function print_LCR(LCR, PRO, SEQ, file_name)

if isempty(LCR) || isempty(SEQ)
    return;
end

% Length of SEQ
L_seq = length(SEQ);

% Open file to print to
fid = fopen(file_name, 'w');

% print title
fprintf(fid, '%s%s%s%s%s%s%s\n', '> ', 'Seq Length=', num2str(L_seq), ', Total LCR Coverage=', num2str(length(PRO.LCR_COV)), ', Relative Coverage=', num2str(PRO.LCR_RC) );

% GO OVER LOW COMPLEXITY REGIONS, found on the seq
Nr = length(LCR);
for r = 1:Nr
    
    % get seq info & locations
    seq_lcr   = LCR(r).seq;
    loc1_lcr  = LCR(r).cov(1);
    loc2_lcr  = LCR(r).cov(end);
    
    % print LCR #, (loc) sequence (loc) 
    fprintf(fid, '%s\t%s%s%s%s%s%s%s\n', num2str(r), '(', num2str(loc1_lcr), ') ', seq_lcr, ' (', num2str(loc2_lcr), ')');
    
end
% Close File
fclose(fid);
