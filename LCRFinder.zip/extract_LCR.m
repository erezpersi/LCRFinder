% SEND:
% --- LOC, INT: the locations and intervals of a FE (taken from lead_fe of CO structure)
% --- LENGTH:   the length of sequenced

% DO:
% --- Analyze all FEs cases with INT <=K. These are runs/doublets/triplets (for AA) or microsatellites (for NT)
%     Get locations/coverage of all these cases... => this gives the intial extraction of LCRs

% GET:
% --- LCR: a structure that contains the locations of low complexity regions (LCR) - identified by each FE

function LCR = extract_LCR(CO, K, SEQ)

if isempty(CO)
    LCR = [];
    return;
end

% sequence length
LENGTH = length(SEQ);

% INIT
LCR   = struct([]);
LCR_COV = [];

% GO OVER EACH FE and extract the LCR associated with it
FE  = CO.lead_fe;
Nfe = length(FE);
for f = 1:Nfe
    
    % Init
    tmp_LCR = struct([]);
    
    % length of K-mers used to build the input CO structure (note that here this can be different than K, see calling in 'analyze_LCR.m') 
    Lfe = length(FE{f});
    
    % FE locations and intervals
    tmp_LOC = CO.lead_loc{f};
    tmp_INT = CO.lead_int{f};
    
    % find the locations of the FE when I<=K
    lcr_id  = find(tmp_INT <= K);
    if isempty(lcr_id)
        continue;
    end
    lcr_loc = tmp_LOC(unique([lcr_id lcr_id+1]));
    % remove overlap with existing LCRs (identified so far) => consider only the non-overalpping parts
    lcr_loc = setdiff(lcr_loc, LCR_COV);
    % skip if completely overlap
    if isempty(lcr_loc)
        continue;
    end
        
    % get spatially distinct LCRs (i.e., by I > K)
    lcr_int = diff(lcr_loc);
    tot_rep = length(lcr_loc);
    id_region  = find(lcr_int > K);
    num_region = length(id_region) + 1;
    if isempty(id_region)
        tmp_LCR(1).fe  = FE{f};
        tmp_LCR(1).loc = lcr_loc;
        tmp_LCR(1).int = lcr_int;
        tmp_loc1 = min(lcr_loc);
        tmp_loc2 = min([max(lcr_loc)+Lfe-1, LENGTH]);
        tmp_LCR(1).cov = tmp_loc1:tmp_loc2;
    else
        for a = 1:num_region
            if a==1
                tmp_LCR(a).fe  = FE{f};
                tmp_LCR(a).loc = lcr_loc(1:id_region(1));
                tmp_LCR(a).int = diff(tmp_LCR(a).loc);
                tmp_loc1 = min(tmp_LCR(a).loc);
                tmp_loc2 = min([max(tmp_LCR(a).loc)+Lfe-1, LENGTH]);
                tmp_LCR(a).cov = tmp_loc1:tmp_loc2;
            elseif a==num_region
                tmp_LCR(a).fe  = FE{f};
                tmp_LCR(a).loc = lcr_loc(id_region(end)+1:tot_rep);
                tmp_LCR(a).int = diff(tmp_LCR(a).loc);
                tmp_loc1 = min(tmp_LCR(a).loc);
                tmp_loc2 = min([max(tmp_LCR(a).loc)+Lfe-1, LENGTH]);
                tmp_LCR(a).cov = tmp_loc1:tmp_loc2;
            else
                tmp_LCR(a).fe  = FE{f};
                tmp_LCR(a).loc = lcr_loc(id_region(a-1)+1:id_region(a));
                tmp_LCR(a).int = diff(tmp_LCR(a).loc);
                tmp_loc1 = min(tmp_LCR(a).loc);
                tmp_loc2 = min([max(tmp_LCR(a).loc)+Lfe-1, LENGTH]);
                tmp_LCR(a).cov = tmp_loc1:tmp_loc2;
            end
        end
    end
    
    % the Array of Low Complexity Regions (LCR)
    LCR = [LCR tmp_LCR];
    clear tmp_* lcr_*
    
    % get the accumulated locations of ALL LCRs (Coverage)
    Nr = length(LCR);
    LCR_COV = [];
    for r = 1:Nr
        LCR_COV = [LCR_COV LCR(r).cov];
    end
    
end

