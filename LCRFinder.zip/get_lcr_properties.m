% SEND:
% --- LCR: output of 'extract_LCR.m'

% GET:
% --- PROPERTIES. Structure that contains:
%     * LCR_COV: locations represting the total coverage of all LCRs
%     * LCR_AB:  the (unique) alphabet of the FEs participating in LCRs 

%     * LCR vs. Non-LCR sequence entropy
%     * RC....

function PROPERTIES = get_lcr_properties(LCR, K, SEQ)

% if isempty(LCR)
%     PROPERTIES = struct([]);
%     return;
% end
% number of regions (by FE recurrences)
Nr = length(LCR);

% get the accumulated locations of ALL LCRs (Coverage)
LCR_COV = [];
for r = 1:Nr
    LCR_COV = [LCR_COV LCR(r).cov];
end
LCR_COV = sort(unique(LCR_COV));

% get the relative coverage of LCRs
LCR_RC = length(LCR_COV)./length(SEQ);

% get the accumulated participating alphabet of ALL LCRs
LCR_AB = [];
for r = 1:Nr
    LCR_AB = unique([LCR_AB LCR(r).alphabet]);
end

% SAVE
PROPERTIES.LCR_COV = LCR_COV;
PROPERTIES.LCR_RC  = LCR_RC;
PROPERTIES.LCR_AB  = LCR_AB;


