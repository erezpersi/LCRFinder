function [prb_ft, num_ft] = analytic_approximation(L, r, A, K)

elements = A^K;
% probability of having a single Element recurring at least "r" times in L
prb_ft = 1 - binocdf(r-1, L, 1/elements); % Pr(>=r)
% number of expected Elements appearing at least "r" times in L
num_ft = elements.*prb_ft;
