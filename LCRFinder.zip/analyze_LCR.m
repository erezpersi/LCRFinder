% SEND:
% --- SEQ: the sequence analyzed
% --- CO:  the output of analyze_CO at level K.
% --- K:   the K-mer length (e.g., K=6 for NT, K=3 for AA)
% --- A:   size of seq alphabet (i.e., A=4 for NT, A=20 for AA)
% --- N_rand: the thereshold on the expected number of FEs within LIMIT that define FEs (typically N_rand = 0.001)
% --- RESOLUTION (USER OPTION):
%     * Low:    only tracks considering ovelapping (I<=K) recurrences of FE at level K alone. 
%     * Medium: only tracks, but considering also irregular recurrences of FEs at levels < K (note: contaminations of tracks coming only from merging recurrences by I<=K)
%     * High:   allows up to 1 gap (i.e., K=1 Q_QQ_Q, K=2 QA_QAQAQA_QA...).

% DO:
% --- get all irregular recurrences for k = 1,2...K, and take all recurrences with I<=K to extract LCRs

% GET:
% --- LCR: a strcuture containing the information of the LCRs (covergae/location, seq...)

function LCR = analyze_LCR(SEQ, CO, K, A, LIMIT, N_rand, RESOLUTION)

if isempty(RESOLUTION)
    disp('Choose LCR resolution');
    LCR = struct([]);
    return;
end

% 1) Initial extraction of LCRs - based on coverage of FE recurrences at the level K (provided in the CO strcuture from MAIN)
LCR = extract_LCR(CO, K, SEQ);

% 2) Control the RESOLUTION at which to extract LCRs:
%    a) To extract only pure tracks of letters (i.e., AAAA, QAQAQA, SRDSRDSRD...)
%       SKIP THIS STEP BELOW (i.e., use only LCR and CO at level K from step 1. )
if ~strcmpi(RESOLUTION, 'LOW')
%    b) TO extract finer resolution of LCRs, considerining also low entropy regions - add also irregular recurrences at levels < K 
%       Calculate CO at all levels up to K (i.e., 1,2...K). 
%       Allow no gaps (Medium resolution) or 1 gap (HIGH resolution) between consecutive recurrences of FEs.
    for i = 1:K-1
        
        tmp_LCR = [];
        
        % all (min_rep, LIMIT) sets that define FEs at level K=i
        [tmp_min_rep, tmp_LIMIT] = determine_search_parameters(LIMIT, N_rand, A, i);
        
        % get the CO structure for K-mers at level K=i
        tmp_CO_i   = analyze_CO(SEQ, i, tmp_min_rep, tmp_LIMIT);
        
        % get the LCR
        if strcmpi(RESOLUTION, 'MEDIUM')
            tmp_LCR  = extract_LCR(tmp_CO_i, i, SEQ);   % consider I <= K for K = K-1...1 (i.e., for AA, K=3, runs and doublets must be consecutive with no gaps: AAAA, QAQAQA)
        end
        if strcmpi(RESOLUTION, 'HIGH')
            %tmp_LCR  = extract_LCR(tmp_CO, K, SEQ);  % consider I <= K for fixed K (i.e., for AA, K=3, consecutive runs can have up to 2aa gap, doublets up to 1aa gap A_A__AAA_AA, QA_QAQA_QA)
            tmp_LCR  = extract_LCR(tmp_CO_i, i+1, SEQ); % consider I <= K for K = K, K-1...2 (i.e., for AA, K=3, consecutive runs can have up to 1aa gap, doublets too: A_A_AA, QA_QAQA_QA)
        end
        
        % merge
        LCR = [LCR tmp_LCR];
        clear tmp_*
    end
end

% 3) Split & Merge LCRs tracks to distinct regions (by I > K)
LCR = process_LCR(LCR, K, SEQ);

% 4) Remove too small strcutures (<=K)
N = length(LCR);
count = 0;
for i = 1:N
    if length(LCR(i).seq) <= K
        count = count + 1;
        id_rm(count) = i;
    end
end
if count > 0
    LCR(id_rm) = [];
end
