% SEND:
% --- LCR: output of 'extract_LCR.m' (intial LCRs based on K-mers stat)
% --- K:   the length of FE motifs
% --- SEQ: char of the seq analyzed

% DO:
% --- unit the location/coverage of all LCRs (of all FEs) => split to distinct regions (I > K)

% GET:
% --- new_LCR. Updated structure of distinct (LCR) regions, providing for each region:
%     * COV:  the coverage (locations) of the LCR
%     * SEQ:  the sequence of the LCR
%     * ALPHABET: the unique letters in LCR

function new_LCR = process_LCR(LCR, K, SEQ)

if isempty(LCR)
    new_LCR = struct([]);
    return;
end

% number of regions (associated with FEs recurrences)
Nr = length(LCR);
% get the accumulated locations of ALL LCRs (Coverage)
LCR_COV = [];
for r = 1:Nr
    LCR_COV = [LCR_COV LCR(r).cov];
end
LCR_COV = sort(unique(LCR_COV));

% PROCESS LCR_COV => Split to regions and their Alphabet
tot_rep    = length(LCR_COV);
id_region  = find(diff(LCR_COV) > K);
num_region = length(id_region) + 1;
if isempty(id_region)
    new_LCR(1).cov      = LCR_COV;
    new_LCR(1).cov      = min(new_LCR(1).cov):max(new_LCR(1).cov);
    new_LCR(1).seq      = SEQ(new_LCR(1).cov);
    %new_LCR(1).alphabet = unique(new_LCR(1).seq);
    [tmp_alphabet, tmp_weights]  = get_alphabet_weights(new_LCR(1).seq);
    new_LCR(1).alphabet = tmp_alphabet;
    new_LCR(1).weights  = tmp_weights;
else
    for a = 1:num_region
        if a==1
            new_LCR(a).cov      = LCR_COV(1:id_region(1));
            new_LCR(a).cov      = min(new_LCR(a).cov):max(new_LCR(a).cov);
            new_LCR(a).seq      = SEQ(new_LCR(a).cov);
            %new_LCR(a).alphabet = unique(new_LCR(a).seq);
            [tmp_alphabet, tmp_weights]  = get_alphabet_weights(new_LCR(a).seq);
            new_LCR(a).alphabet = tmp_alphabet;
            new_LCR(a).weights  = tmp_weights;
        elseif a==num_region
            new_LCR(a).cov      = LCR_COV(id_region(end)+1:tot_rep);
            new_LCR(a).cov      = min(new_LCR(a).cov):max(new_LCR(a).cov);
            new_LCR(a).seq      = SEQ(new_LCR(a).cov);
            %new_LCR(a).alphabet = unique(new_LCR(a).seq);
            [tmp_alphabet, tmp_weights]  = get_alphabet_weights(new_LCR(a).seq);
            new_LCR(a).alphabet = tmp_alphabet;
            new_LCR(a).weights  = tmp_weights;
        else
            new_LCR(a).cov      = LCR_COV(id_region(a-1)+1:id_region(a));
            new_LCR(a).cov      = min(new_LCR(a).cov):max(new_LCR(a).cov);
            new_LCR(a).seq      = SEQ(new_LCR(a).cov);
            %new_LCR(a).alphabet = unique(new_LCR(a).seq);
            [tmp_alphabet, tmp_weights]  = get_alphabet_weights(new_LCR(a).seq);
            new_LCR(a).alphabet = tmp_alphabet;
            new_LCR(a).weights  = tmp_weights;
        end
    end
    clear tmp_*
end

