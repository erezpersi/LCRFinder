% LCRFinder - IS A FUNCTION TO EXTRACTS LOW COMPLEXITY REGIONS (LCRs) FROM AMINO-ACID and NUCLEOTIDE SEQUENCES
% BASED ON REFERENCE:
% Persi E, Wolf YI, Karamycheva S, Makarova K, Koonin EV (2022). Dynamics of and Compensatory Relationship between Low Complexity Regions and Gene Paralogy in the Evolution of Porkaryotes.
%
% SEND:
% --- SEQ:        a cell array contaning AA or DNA sequences  (output of fastaread.m)
% --- AB:         the alphabet of SEQ ('AA' or 'NT')
% --- RESOLUTION (Optional): the method calculates all irregular recuirrences of all K-mers up to K (=1,2...K), and all cases with I<=K can be used to extract as LCRs.
%     USER OPTIONs are:
%     * 'Low':              only long/pure tracks, considering ovelapping (I<=K) recurrences of FEs at level of maximal K only.
%     * 'Medium' (Default): all tracks, considering all irregular recurrences of FEs at all levels <= K
%     * 'High':             allows up to 1 gap at levels < K (i.e., K=1 Q_QQ_Q, K=2 QA_QAQAQA_QA...).
%     NOTE: all LCRs distant by <= K are merged
%
% EXAMPLES:
%     % --- to process AA sequences
%     [HEADER, SEQ] = fastaread('FASTA_proteins.fasta'); % to read protein sequences from Fasta file
%     RES = run_LCRFinder(SEQ, 'AA');                    % to extract all tracks ('Medium' resolution)
%     RES = run_LCRFinder(SEQ, 'AA', 'Low');             % to extract pure/long tracks
%     RES = run_LCRFinder(SEQ, 'AA', 'High');            % to extract more diverged tracks
%
%     % --- to process NT sequences
%     [HEADER, SEQ] = fastaread('FASTA_dna.fasta');      % to read dna sequences from Fasta file
%     if ischar(SEQ)                                     % SEQ must be a cell Array
%        SEQ = cellstr(SEQ);
%     end
%     RES = run_LCRFinder(SEQ, 'NT');                    % to extract all tracks ('Medium' resolution)

function RES = run_LCRFinder(SEQ, AB, RESOLUTION)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  DEFINE PARAMETERS   %%%
if strcmpi(AB, 'NT')
    A = 4; % Alpha-bet size
    K = 6; % The longest k-mer 
elseif strcmpi(AB, 'AA')
    A = 20;
    K = 3;
end
% --- SEARCH TABLE
LIMIT  = 1000;     % use a global window of 1000 letters to define search table
N_rand = 0.001;    % the threshold of expected No. of FEs within LIMIT 
[min_rep, LIMIT] = determine_search_parameters(LIMIT, N_rand, A, K);
% --- RESOLUTION
if nargin < 3
    RESOLUTION = 'Medium'; % default is Medium
end

% GO OVER SEQUENCES (e.g., proteins, coding DNA, whole-genome)
RES   = [];
Ns = length(SEQ);
%fid = fopen(FILE_NAME, 'w'); % Open file 'LCR' to print to
for s = 1:Ns
    
    s
    L_seq = length(SEQ{s});
%     % --- to skip bad (e.g., too long) sequences
%     if L_seq >= 200000
%         fprintf(fid, '%s%s\t%s\t%s\t%s\n', '> ', ID{s}, 'NaN', 'NaN', 'NaN' );
%         continue;
%     end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%  1) CO & LCR ANALYSIS    %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CO = []; LCR = [];
    
    % --- run Compositional Order (CO) ANALYSIS (statistics of K-mer recurrences)
    CO = analyze_CO(SEQ{s}, K, min_rep, LIMIT);
    if isempty(CO)
%         %fprintf(fid, '%s%s%s%s%s%s%s%s\n', '> ID=', ID{s}, ', Seq Length=', num2str(L_seq), ', Total LCR Coverage=', '0', ', Relative Coverage=', '0' );
%         fprintf(fid, '%s%s\t%s\t%s\t%s\n', '> ', ID{s}, num2str(L_seq), '0', '0');
         continue;
    end
    
    % --- Extract All Low Complexity Regions (I <= K). Consider all I<=K recurrences of all K-mers up to K (i.e., k=1,2...K)
    LCR = analyze_LCR(SEQ{s}, CO, K, A, max(LIMIT), N_rand, RESOLUTION);
    PRO = get_lcr_properties(LCR, K, SEQ{s});     % get LCR properties (total Coverage, alphabet...)
    
    %%%%%%%%%%%%%%%%%
    %%%   PRINT   %%%
    % --- see file:
    print_LCR(LCR, PRO, SEQ{s}, strcat(num2str(s),'_'));
    
    % fprintf(fid, '%s%s\n', '> ', NAME{s} ); % print title
%     if ~isempty(LCR)
%         %fprintf(fid, '%s%s%s%s%s%s%s%s\n', '> ID=', ID{s}, ', Seq Length=', num2str(L_seq), ', Total LCR Coverage=', num2str(length(PRO.LCR_COV)), ', Relative Coverage=', num2str(PRO.LCR_RC) );
%         fprintf(fid, '%s%s\t%s\t%s\t%s\n', '> ', ID{s}, num2str(L_seq), num2str(length(PRO.LCR_COV)), num2str(PRO.LCR_RC));
%     else
%         %fprintf(fid, '%s%s%s%s%s%s%s%s\n', '> ID=', ID{s}, ', Seq Length=', num2str(L_seq), ', Total LCR Coverage=', '0', ', Relative Coverage=', '0' );
%         fprintf(fid, '%s%s\t%s\t%s\t%s\n', '> ', ID{s}, num2str(L_seq), '0', '0');
%     end
          
    % --- SAVE CO & LCR structures in RES
    RES(s).CO    = CO;
    RES(s).LCR   = LCR;
    RES(s).LCR_PROPERTIES = PRO;
    
    
%     if mod(s,1000)==0
%         save('LCR_RES','RES');
%     end
    
end
% Save
% save('LCR_RES','RES');
% Close File
% fclose(fid);

