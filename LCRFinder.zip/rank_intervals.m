% SEND:
% --- INT: the intervals [ = diff(locations)] of the recurrences of a FE

% GET:
% --- PERIOD: sorted unique recurring intervals (periods) & the number they recur. Hence:
%     PERIOD(1) = MFI, and rep_per(1) is the num of repetitions at MFI. 
%     PERIOD(2) & rep_per(2)is the next significant period and so on...


function [PERIOD, rep_per] = rank_intervals(INT)

% --- get number of recurrence of each unique interval
uI = unique(INT);
Nu = length(uI);
for u = 1:Nu
    uR(u) = length(find(INT == uI(u)));
end
% --- sort by recurrences
[uR, id] = sort(uR, 'descend');
uI       = uI(id);
% --- remove non-periodic data (interval must recur at least two times)
id_per  = find(uR >=2);
if ~isempty(id_per)
    PERIOD  = uI(id_per);
    rep_per = uR(id_per);
else
    PERIOD  = 0;
    rep_per = 0;
end
    


