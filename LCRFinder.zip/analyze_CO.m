% SEND:
% --- SEQ:  a cell array contaning a AA/DNA sequence
% --- PAR:  a strcuture with matching vectors of the parameters to set search of non-random recuirrences: 
%           * 'min_rep' - the minimal number of repetitions of the K-mer beyond which the K-mer is defined as FE
%           * 'K'       - the basic K-mer length for finding frequent elements (FE)
%           * 'LIMIT'   - min_rep must occur within a window of LIMIT letters

% GET:
% --- CO: Frequent Elements (FEs) and (ALL) their locations, intervals and repetitions...

% USE:
% load DEVELOPMENT.mat
% CO = analyze_CO(Ecoli_genome{1}, PARAMETERS_dna.K, PARAMETERS_dna.min_rep, PARAMETERS_dna.LIMIT);

function CO = analyze_CO(SEQ, K, min_rep, LIMIT)

CO = [];

% --- Return if Seq is too short ( < 10 letters)
L = length(SEQ);
if L <= 10
    CO = [];
    disp('Sequence is too short');
    return;
end

% --- FIND all Elements (K-mers) in SEQ and get their locations, intervals and no. of repeats
%if K > 6
    [Kmers, REP, INT, LOC] = get_Kmers_stat_with_HashTable(SEQ, K);
%else
%    [Kmers, REP, INT, LOC] = get_Kmers_stat(SEQ, K);
%end
    

% --- GET IDs of Frequent Elements (FEs) - Those K-mers which recur beyond random (as defined by theory)
ID = get_FEs_id(LOC, min_rep, LIMIT);
if isempty(ID)
    disp('NO FREQUENT ELEMENTS FOUND');
    return;
end
% --- SAVE in CO structure (ALL) their repetitions, locations and intervals in the sequence
CO.FEs       = Kmers(ID);
CO.repeats   = REP(ID);
CO.intervals = INT(ID);
CO.locations = LOC(ID);

% --- FILTER random locations from each FE => update CO (save new_ FEs, rep, loc, int)
CO = filter_FEs_loc(CO, min_rep, LIMIT);

% --- SORT FEs (default is most periodic and then most repetitive)
CO = sort_FEs(CO, []);

