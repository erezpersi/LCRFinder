% SEND:
% --- SEQ: cell array of sequences taken from a species genome

% GET:
% --- Letters, Weights:  the weights (probablity) of each AA/NT in SEQ (i.e., in genome or proteome)  

function [Letters, Weights] = get_alphabet_weights(SEQ)

% Existing Alphabet in SEQ
Letters = unique(SEQ);

% count the number occurences of a given letter in alpha_bet, relative to the total length of all sequences
% => Weight is the probablity of occurence
Nab = length(Letters);
L = length(SEQ);
W = zeros(1,Nab);
for j = 1:Nab
    W(j) = W(j) + length(strfind(SEQ, Letters(j)));
end
% Weight Probablity Vector of AB
Weights = W./L;

% Sort by weight
[Weights, ID] = sort(Weights, 'descend');
Letters = Letters(ID);

