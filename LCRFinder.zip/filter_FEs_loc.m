% NOTE: get_FEs_id.m filters for *ELEMENTS* (=>they must be FE) BUT it does not filter the actual locations (it considers all the locations/instances of an FE).
%       The current function removes *INSTANCES* that do not occur min_rep within LIMIT

% SEND:
% --- CO: the results structure of 'analyze_CO.m' (contains the identity, locations and intervals of each Frequent Element)
% --- min_rep, K, LIMIT: the parametrization defining FEs

% DO:
% --- keep intances of recurrences (i.e., locations) only if/when they recur min_rep within LIMIT
%     (that is, intances of the element that are too distant will be removed)

% GET:
% --- CO: Updated CO structure with the new FEs, loc, int , rep... (as new fields)

function CO = filter_FEs_loc(CO, min_rep, LIMIT)

% INIT => these will eventually contain only recurrences beyond random
new_FEs = [];
new_LOC = [];
new_INT = [];
new_REP = [];

% GO OVER each FE in this SEQ
FEs   = CO.FEs;
LOC   = CO.locations;
Nf    = length(CO.FEs);
Npar  = length(min_rep);
% --- FEs that eventually will pass the filtering and be kept (with their recurrences within LIMIT)
keep_count = 0;
for f = 1:Nf
    
    % CHECK LOCALITY - GO OVER all LOCATIONS & keep only the instances where min_rep is within LIMIT
    %                  [Note: 'get_FEs_id.m' filters for FEs, but it keeps all their locations]
    loc_fe = LOC{f};
    loc_N  = length(loc_fe);
    % --- go over every 'min_rep' repeats and check if appeared within the corresponding LIMIT
    keep_loc  = [];
    for i = 1:Npar
        for k = 1:loc_N-min_rep(i)+1
            loc_dis = -(loc_fe(k) - loc_fe(k+min_rep(i)-1));
            % if the distance is over LIMIT = > ignore the first location and move on
            if loc_dis > LIMIT(i)
                continue;
            % if the distance is within LIMIT = > tag all min_rep as valid (keep'em) and move to the second/next location
            else
                tmp_loc  = loc_fe(k:k+min_rep(i)-1);
                keep_loc = unique([tmp_loc keep_loc]);
            end
            clear loc_dis tmp_loc
        end
    end
    if ~isempty(keep_loc)
        keep_count = keep_count + 1;
        keep_fe = FEs{f};
        % SAVE
        new_FEs{keep_count} = keep_fe;
        new_LOC{keep_count} = keep_loc;
        new_INT{keep_count} = diff(keep_loc);
        new_REP(keep_count) = length(keep_loc);
    end
    
    clear loc_*
end

% Update CO structure
CO.new_FEs  = new_FEs;  % the K-mer motifs
CO.new_LOC  = new_LOC;  % their locations
CO.new_INT  = new_INT;  % their intervals
CO.new_REP  = new_REP;  % No. of repetitions


